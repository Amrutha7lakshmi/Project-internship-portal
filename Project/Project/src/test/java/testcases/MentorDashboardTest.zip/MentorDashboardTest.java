package testcases;

import pages.MentorDashboard;
import utilities.AutomationConstants;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBase;
import pages.LoginPage;

public class MentorDashboardTest extends TestBase {
	
	LoginPage lObj;
    MentorDashboard mObj;
    
    @BeforeClass
	public void bfClass()
	{
		lObj=new LoginPage(driver);
		mObj=new MentorDashboard(driver); //object initialization
		
	}
    @Test
	public void prjctList()
	{
		lObj.lgnButton("arjun@example.com","Arjun@4444");
		//aObj.waitForProjectListToUpdate();
		String actResult=mObj.allotedPrjct();
		Assert.assertEquals(actResult, AutomationConstants.prjct1);
		String actResult1=mObj.viewNextAllotedPrjct();
		Assert.assertEquals(actResult1, AutomationConstants.prjct2);
		mObj.referenceClick();
		mObj.addReference();
		mObj.addReferenceForm();
		mObj.popMssg();
		mObj.deleteReference();
		mObj.mentorLogout();

	}

}
